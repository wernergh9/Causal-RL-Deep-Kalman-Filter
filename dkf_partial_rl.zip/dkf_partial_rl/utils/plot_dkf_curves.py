import matplotlib.pyplot as plt
import pandas as pd
import os

os.makedirs("DKF_train_curves/", exist_ok=True)

train_data = pd.read_csv("DKF_trainings/20230114/232926_DKF/train.csv", sep=",")
val_data = pd.read_csv("DKF_trainings/20230114/232926_DKF/eval.csv", sep=",")


train_elbo = train_data['loss']
train_recon = train_data['llh loss']
train_KLD = train_data['KLD loss']
train_betaKLD = train_data['beta*KLD loss']
train_EKLD = train_data['EKLD loss']
train_betaEKLD = train_data['beta*EKLD loss']

val_elbo = val_data['loss']
val_recon = val_data['llh loss']
val_KLD = val_data['KLD loss']
val_betaKLD = val_data['beta*KLD loss']
val_EKLD = val_data['EKLD loss']
val_betaEKLD = val_data['beta*EKLD loss']

########### ELBO CURVES ###################################################

fig, ax = plt.subplots(nrows=2, ncols=4, figsize=(18,8))
ax[0][0].plot(range(1,len(train_elbo)+1),train_elbo)
ax[0][0].tick_params(axis='x', labelsize=15)
ax[0][0].tick_params(axis='y', labelsize=15)
ax[0][0].set_title("Train ELBO", size=18)
ax[0][0].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][1].plot(range(1,len(train_recon)+1),train_recon)
ax[0][1].tick_params(axis='x', labelsize=15)
ax[0][1].tick_params(axis='y', labelsize=15)
ax[0][1].set_title("Train  Recon Loss", size=18)
ax[0][1].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][2].plot(range(1,len(train_betaKLD)+1),train_betaKLD, label="beta KLD")
ax[0][2].plot(range(1,len(train_KLD)+1),train_KLD, label="KLD")
ax[0][2].tick_params(axis='x', labelsize=15)
ax[0][2].tick_params(axis='y', labelsize=15)
ax[0][2].legend()
ax[0][2].set_title("Train KLD loss", size=18)
ax[0][2].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][3].plot(range(1,len(train_betaEKLD)+1),train_betaEKLD, label="beta EKLD")
ax[0][3].plot(range(1,len(train_EKLD)+1),train_EKLD, label="EKLD")
ax[0][3].tick_params(axis='x', labelsize=15)
ax[0][3].tick_params(axis='y', labelsize=15)
ax[0][3].legend()
ax[0][3].set_title("Train EKLD loss", size=18)


ax[1][0].plot(range(1,len(val_elbo)+1),val_elbo)
ax[1][0].tick_params(axis='x', labelsize=15)
ax[1][0].tick_params(axis='y', labelsize=15)
ax[1][0].set_title("Val ELBO", size=18)
ax[1][0].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][1].plot(range(1,len(val_recon)+1),val_recon)
ax[1][1].tick_params(axis='x', labelsize=15)
ax[1][1].tick_params(axis='y', labelsize=15)
ax[1][1].set_title("Val  Recon Loss", size=18)
ax[1][1].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][2].plot(range(1,len(val_betaKLD)+1),val_betaKLD, label="beta KLD")
ax[1][2].plot(range(1,len(val_KLD)+1),val_KLD, label="KLD")
ax[1][2].tick_params(axis='x', labelsize=15)
ax[1][2].tick_params(axis='y', labelsize=15)
ax[1][2].legend()
ax[1][2].set_title("Val KLD loss", size=18)
ax[1][2].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][3].plot(range(1,len(val_betaEKLD)+1),val_betaEKLD, label="beta EKLD")
ax[1][3].plot(range(1,len(val_EKLD)+1),val_EKLD, label="EKLD")
ax[1][3].tick_params(axis='x', labelsize=15)
ax[1][3].tick_params(axis='y', labelsize=15)
ax[1][3].legend()
ax[1][3].set_title("Val EKLD loss", size=18)
plt.tight_layout()
plt.savefig('DKF_train_curves/ELBO_train_val_curves.png')


############# RECONSTRUCTION CURVES ######################################

train_recon = train_data['llh loss']
train_o_recon = train_data['grid llh loss']
train_r_recon = train_data['reward llh loss']
train_d_recon = train_data['term_state llh loss']
train_a_recon = train_data['action llh loss']


val_recon = val_data['llh loss']
val_o_recon = val_data['grid llh loss']
val_r_recon = val_data['reward llh loss']
val_d_recon = val_data['term_state llh loss']
val_a_recon = val_data['action llh loss']


fig, ax = plt.subplots(nrows=2, ncols=5, figsize=(20,8))
ax[0][0].plot(range(1,len(train_recon)+1),train_recon)
ax[0][0].tick_params(axis='x', labelsize=15)
ax[0][0].tick_params(axis='y', labelsize=15)
ax[0][0].set_title("Train Recon", size=18)
ax[0][0].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][1].plot(range(1,len(train_o_recon)+1),train_o_recon)
ax[0][1].tick_params(axis='x', labelsize=15)
ax[0][1].tick_params(axis='y', labelsize=15)
ax[0][1].set_title("Train Obs Recon", size=18)
ax[0][1].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][2].plot(range(1,len(train_r_recon)+1),train_r_recon)
ax[0][2].tick_params(axis='x', labelsize=15)
ax[0][2].tick_params(axis='y', labelsize=15)
ax[0][2].set_title("Train Reward Recon", size=18)
ax[0][2].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][3].plot(range(1,len(train_d_recon)+1),train_d_recon)
ax[0][3].tick_params(axis='x', labelsize=15)
ax[0][3].tick_params(axis='y', labelsize=15)
ax[0][3].set_title("Train Done Recon", size=18)
ax[0][3].get_yaxis().get_major_formatter().set_useOffset(False)
ax[0][4].plot(range(1,len(train_a_recon)+1),train_a_recon)
ax[0][4].tick_params(axis='x', labelsize=15)
ax[0][4].tick_params(axis='y', labelsize=15)
ax[0][4].set_title("Train Action Recon", size=18)
ax[0][4].get_yaxis().get_major_formatter().set_useOffset(False)


ax[1][0].plot(range(1,len(val_recon)+1),val_recon)
ax[1][0].tick_params(axis='x', labelsize=15)
ax[1][0].tick_params(axis='y', labelsize=15)
ax[1][0].set_title("Val Recon", size=18)
ax[1][0].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][1].plot(range(1,len(val_o_recon)+1),val_o_recon)
ax[1][1].tick_params(axis='x', labelsize=15)
ax[1][1].tick_params(axis='y', labelsize=15)
ax[1][1].set_title("Val Obs Recon", size=18)
ax[1][1].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][2].plot(range(1,len(val_r_recon)+1),val_r_recon)
ax[1][2].tick_params(axis='x', labelsize=15)
ax[1][2].tick_params(axis='y', labelsize=15)
ax[1][2].set_title("Val Reward Recon", size=18)
ax[1][2].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][3].plot(range(1,len(val_d_recon)+1),val_d_recon)
ax[1][3].tick_params(axis='x', labelsize=15)
ax[1][3].tick_params(axis='y', labelsize=15)
ax[1][3].set_title("Val Done Recon", size=18)
ax[1][3].get_yaxis().get_major_formatter().set_useOffset(False)
ax[1][4].plot(range(1,len(val_a_recon)+1),val_a_recon)
ax[1][4].tick_params(axis='x', labelsize=15)
ax[1][4].tick_params(axis='y', labelsize=15)
ax[1][4].set_title("Val Action Recon", size=18)
ax[1][4].get_yaxis().get_major_formatter().set_useOffset(False)
plt.tight_layout()

plt.savefig('DKF_train_curves/Recon_train_val_curves.png')


