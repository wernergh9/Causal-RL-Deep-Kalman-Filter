import numpy as np
import torch
import time
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import torch.nn.functional as F


def get_cols(array_len,window_size,stride):

    windows = np.floor(array_len/window_size)

    if windows==0:
        return 0

    resid = (array_len%window_size)+(windows-1)*stride

    windows += get_cols(resid+stride,window_size,stride)
    
    return windows

def mix_datasets(expert_dataset, rand_dataset, replace_dict=False):
    obs = np.concatenate((expert_dataset['obs'],rand_dataset['obs']),axis=0)
    actions = np.concatenate((expert_dataset['actions'],rand_dataset['actions']),axis=0)
    term_states = np.concatenate((expert_dataset['term_states'],rand_dataset['term_states']),axis=0)
    term_states_mask = np.concatenate((expert_dataset['term_states_mask'],rand_dataset['term_states_mask']),axis=0)
    regimen = np.concatenate((expert_dataset['regimen'],rand_dataset['regimen']),axis=0)

    if replace_dict:
      obs_elements_map = dict((el,i) for i,el in enumerate(np.unique(obs[:,:,0:-1])))

      def mp(entry):
        return obs_elements_map[entry] if entry in obs_elements_map else entry
      
      mp = np.vectorize(mp)
      obs[:,:,0:-1] = mp(obs[:,:,0:-1])

      return {'obs':obs, 'actions':actions, 'term_states':term_states, 'regimen':regimen, 'term_states_mask':term_states_mask}, obs_elements_map

    return {'obs':obs, 'actions':actions, 'term_states':term_states, 'regimen':regimen, 'term_states_mask':term_states_mask}, None

def train_test_split_(mixed_dataset, test_size, random_state):
    obs = mixed_dataset['obs']
    actions = mixed_dataset['actions']
    term_states = mixed_dataset['term_states']
    term_states_mask = mixed_dataset['term_states_mask']
    regimen = mixed_dataset['regimen']

    obs_train, obs_val, \
    actions_train, actions_val, \
    term_states_train, term_states_val, \
    regimen_train, regimen_val, \
    term_states_mask_train, term_states_mask_val = train_test_split(
        obs,
        actions,
        term_states,
        regimen, 
        term_states_mask,
        test_size=test_size, 
        random_state=random_state
    )

    train = {'obs':obs_train, 'actions':actions_train, 'term_states':term_states_train, 'regimen':regimen_train, 'term_states_mask':term_states_mask_train}
    val = {'obs':obs_val, 'actions':actions_val, 'term_states':term_states_val, 'regimen':regimen_val, 'term_states_mask':term_states_mask_val}

    return train, val


class MinigridData():
    def __init__(self, dataset):

        self.obs = dataset['obs']
        self.actions = dataset['actions']
        self.term_states = dataset['term_states']
        self.regimen = dataset['regimen']
        self.term_states_mask = dataset['term_states_mask']

    def __len__(self):
        return len(self.obs)
    
    def __getitem__(self, index):
        obs = torch.from_numpy(self.obs[index][:,0:-1].reshape(-1,1,7,7)).float()
        rewards = torch.from_numpy(self.obs[index][:,-1]).float()
        action = torch.from_numpy(self.actions[index]).float()
        term_states = torch.from_numpy(self.term_states[index]).float()
        term_states_mask = torch.from_numpy(self.term_states_mask[index]).float()
        regimen = torch.from_numpy(self.regimen[index]).float()

        return {'obs': obs, 'rewards': rewards, 'actions':action, 'term_states':term_states, 'regimen': regimen, 'term_states_mask':term_states_mask}

def fix_dataset_format(dataset):
    obs = dataset['obs_set']
    actions = dataset['actions']
    term_state = dataset['Terminated']
    ep_indexs = np.array(dataset['ep_indexs'])

    split_indexs = ep_indexs[:,1]+1
    if split_indexs[-1] == 0:
        split_indexs = split_indexs[:-1]
        obs = obs[:split_indexs[-1]]
        actions = actions[:split_indexs[-1]]
        term_state = term_state[:split_indexs[-1]]
    
    split_indexs = split_indexs[0:-1]

    obs_split = np.split(obs, split_indexs)
    actions_split = np.split(actions, split_indexs)
    term_state_split = np.split(term_state, split_indexs)

    return {'obs':obs_split, 'actions':actions_split, 'term_states': term_state_split}

def pad_datasets(expert_dataset, rand_dataset):

  expert_obs = expert_dataset['obs']
  expert_actions = expert_dataset['actions']
  expert_term_states = expert_dataset['term_states']

  rand_obs = rand_dataset['obs']
  rand_actions = rand_dataset['actions']
  rand_term_states = rand_dataset['term_states']


  max_sequence_len = max(max([actions.shape[0] for actions in expert_actions]), max([actions.shape[0] for actions in rand_actions]))
  
  expert_obs_pad = [np.expand_dims(np.pad(obs, ((0, max_sequence_len-obs.shape[0]),(0,0))),axis=0) for obs in expert_obs]
  expert_obs_pad = np.concatenate(expert_obs_pad, axis=0)
  expert_actions_pad = [np.expand_dims(np.pad(actions, (0,max_sequence_len- len(actions))),axis=0) for actions in expert_actions]
  expert_actions_pad = np.concatenate(expert_actions_pad, axis=0)
  expert_term_states_pad = [np.expand_dims(np.pad(term_state, (0,max_sequence_len- len(term_state))),axis=0) for term_state in expert_term_states]
  expert_term_states_pad = np.concatenate(expert_term_states_pad, axis=0)

  expert_term_states_mask = [np.expand_dims(np.pad(np.ones_like(term_state), (0,max_sequence_len- len(term_state))),axis=0) for term_state in expert_term_states]
  expert_term_states_mask = np.concatenate(expert_term_states_mask, axis=0)

  rand_obs_pad = [np.expand_dims(np.pad(obs, ((0, max_sequence_len-obs.shape[0]),(0,0))),axis=0) for obs in rand_obs]
  rand_obs_pad = np.concatenate(rand_obs_pad, axis=0)
  rand_actions_pad = [np.expand_dims(np.pad(actions, (0,max_sequence_len- len(actions))),axis=0) for actions in rand_actions]
  rand_actions_pad = np.concatenate(rand_actions_pad, axis=0)
  rand_term_states_pad = [np.expand_dims(np.pad(term_state, (0,max_sequence_len- len(term_state))),axis=0) for term_state in rand_term_states]
  rand_term_states_pad = np.concatenate(rand_term_states_pad, axis=0)

  rand_term_states_mask = [np.expand_dims(np.pad(np.ones_like(term_state), (0,max_sequence_len- len(term_state))),axis=0) for term_state in rand_term_states]
  rand_term_states_mask = np.concatenate(rand_term_states_mask, axis=0)


  expert_regimes = np.zeros_like(expert_actions_pad)
  rand_regimes = np.ones_like(rand_actions_pad)

  new_expert_dataset = {'obs': expert_obs_pad,
                        'actions':expert_actions_pad,
                        'term_states':expert_term_states_pad,
                        'regimen': expert_regimes,
                        'term_states_mask': expert_term_states_mask}

  new_rand_dataset = {'obs': rand_obs_pad,
                      'actions':rand_actions_pad,
                      'term_states':rand_term_states_pad,
                      'regimen': rand_regimes,
                      'term_states_mask': rand_term_states_mask}

  return new_expert_dataset, new_rand_dataset


def float_keys_to_str(dict):
    new_dict = {}
    for key in list(dict.keys()):
      new_dict[str(key)] = dict[key]
    return new_dict

def str_keys_to_float(dict):
    new_dict = {}
    for key in list(dict.keys()):
      new_dict[float(key)] = dict[key]
    return new_dict


def loss_function(epoch, data, decoder_params, mu_z, logvar_z, mu_z_next, logvar_z_next, logger=None, which_set=''):

    device = decoder_params['grid_params'].device
    batches = data['obs'].shape[0]
    time_steps = data['obs'].shape[1]
    time_mask = data['term_states_mask'].to(device)

    # Grid Loss
    grid_categorical = torch.distributions.Categorical(logits=decoder_params['grid_params'])
    grid_nll = time_mask*torch.sum(grid_categorical.log_prob(data['obs'].to(device).reshape(batches, time_steps, -1)),dim=2)
    grid_nll = -torch.mean(torch.sum(grid_nll,dim=1))
    
    # Reward Loss
    weights = decoder_params['reward_params']['weights']
    mix = torch.distributions.Categorical(logits=weights)
    normal_comp = torch.distributions.Normal(decoder_params['reward_params']['mus'], torch.exp(0.5*decoder_params['reward_params']['logvars']))
    gaussian_mixture = torch.distributions.mixture_same_family.MixtureSameFamily(mix,normal_comp)
    reward_nll = -torch.mean(torch.sum(time_mask*gaussian_mixture.log_prob(data['rewards'].to(device)),dim=1))

    # Term State Loss
    bernoulli = torch.distributions.bernoulli.Bernoulli(logits=torch.squeeze(decoder_params['term_state_params'],dim=2))
    term_state_nll = -torch.mean(torch.sum(time_mask*bernoulli.log_prob(data['term_states'].to(device)),dim=1))

    # Action Loss
    actions_categorical = torch.distributions.Categorical(logits=decoder_params['action_params'])

    term_state_mask = ~data['term_states'].bool()
    regime_mask = ~data['regimen'].bool()
    mask = (term_state_mask * regime_mask).to(device) # discard actions if done=True or i=1
    #action_nll = -torch.mean(torch.sum(mask*actions_categorical.log_prob((data['actions']+1).to(device)),dim=1))

    action_nll = -torch.mean(torch.sum(time_mask*mask*actions_categorical.log_prob((data['actions']+1).to(device)),dim=1))
   

    #Compute NLL
    nll = grid_nll+reward_nll+term_state_nll+action_nll 

    # Save parts of NLL
    nll_parts = torch.Tensor([grid_nll.item(), reward_nll.item(), term_state_nll.item(), action_nll.item()])

    # see Appendix B from VAE paper:
    # Kingma and Welling. Auto-Encoding Variational Bayes. ICLR, 2014
    # https://arxiv.org/abs/1312.6114
    # 0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)

    mu_z1 = mu_z[:,0,:]
    logvar_z1 = logvar_z[:,0,:]

    KLD = torch.mean(0.5 * torch.sum(mu_z1.pow(2) + logvar_z1.exp() - logvar_z1 - 1,dim=1))

    mu_zs = mu_z[:,1:,:][None,:,:,:]
    logvar_zs = logvar_z[:,1:,:][None,:,:,:]

    EKLD = torch.mean(torch.sum(time_mask[:,1:]*torch.mean(0.5*torch.sum(-1+logvar_z_next-logvar_zs+
                                      logvar_zs.exp()/logvar_z_next.exp() +
                                      (mu_z_next-mu_zs).pow(2)/logvar_z_next.exp(),dim=3), dim=0),dim=1))

    return nll, nll_parts, KLD, EKLD

def train_epoch(epoch, model, optimizer, train_loader, beta, sample_size, logger=None):
    model.train()
    train_loss = 0
    llh_loss, KLD_loss, EKLD_loss = 0, 0, 0
    llh_parts_loss = torch.zeros(4)

    for batch_idx, data in enumerate(train_loader):
        optimizer.zero_grad()

        decoder_params, mu_z, logvar_z, mu_z_nexts, logvar_z_nexts = model(data, sample_size=sample_size)

        nll, nll_parts, KLD, EKLD = loss_function(epoch,
                                                  data,
                                                  decoder_params,
                                                  mu_z,
                                                  logvar_z,
                                                  mu_z_nexts,
                                                  logvar_z_nexts,
                                                  logger=logger,
                                                  which_set='train')
        loss = nll+beta*(KLD+EKLD)
        loss.backward()
        optimizer.step()

        llh_loss += -nll.item()
        llh_parts_loss += -nll_parts
        KLD_loss += beta*KLD.item()
        EKLD_loss += beta*EKLD.item()
        train_loss += (-loss).item()
    
    train_loss /=len(train_loader)
    llh_loss /=len(train_loader)
    KLD_loss /=len(train_loader)
    EKLD_loss /=len(train_loader)
    llh_parts_loss /= len(train_loader)

    return model, train_loss, llh_loss, llh_parts_loss, KLD_loss, EKLD_loss


def val_epoch(epoch, model, test_loader, beta, sample_size, logger=None):
    model.eval()
    test_loss = 0
    llh_loss, KLD_loss, EKLD_loss = 0, 0, 0
    llh_parts_loss = torch.zeros(4)
    with torch.no_grad():
        for i, data in enumerate(test_loader):

            decoder_params, mu_z, logvar_z, mu_z_nexts, logvar_z_nexts = model(data, sample_size=sample_size)
            
            nll, nll_parts, KLD, EKLD = loss_function(epoch,
                                           data,
                                           decoder_params,
                                           mu_z,
                                           logvar_z,
                                           mu_z_nexts,
                                           logvar_z_nexts,
                                           logger=logger,
                                           which_set='eval')

            llh_loss += -nll.item()
            llh_parts_loss += -nll_parts
            KLD_loss += beta*KLD.item()
            EKLD_loss += beta*EKLD.item()
            test_loss += (-nll-beta*(KLD+EKLD)).item()
    test_loss /= len(test_loader)
    llh_parts_loss /= len(test_loader)
    llh_loss /=len(test_loader)
    KLD_loss /=len(test_loader)
    EKLD_loss /=len(test_loader)

    return model, test_loss, llh_loss, llh_parts_loss, KLD_loss, EKLD_loss



def train(model_state, train_loader, cfg, val_loader=None, logger=None):
  
  N_t = cfg["N_t"]
  epochs = cfg['epochs']
  beta_max = cfg['beta_max']
  sample_size = cfg['sample_size']
  checkpoint_freq = cfg['checkpoint_frequency']
  checkpoint_path = cfg['checkpoint_path']
  final_model_path = cfg['final_model_path']

  model = model_state['model']
  optimizer = model_state['optimizer']
  start_epoch = model_state['epoch']

  if start_epoch >= epochs:
    return model


  tau =  N_t/5
  beta = [beta_max*(1-np.exp(-t/tau)) for t in range(epochs)]

  for epoch in tqdm(range(start_epoch+1, epochs + 1)):
    try:
      start_time = time.time()
      model, train_loss, train_llh_loss, train_llh_parts_loss, train_KLD_loss, train_EKLD_loss = train_epoch(epoch,
                                                                                                             model,
                                                                                                             optimizer,
                                                                                                             train_loader,
                                                                                                             beta[epoch-1],
                                                                                                             sample_size,
                                                                                                             logger=logger)                                                                                                     
      logger.log('train/duration', time.time() - start_time, epoch)

      if val_loader:
        start_time = time.time()
        model, val_loss, val_llh_loss, val_llh_parts_loss, val_KLD_loss, val_EKLD_loss = val_epoch(epoch,
                                                                                                   model,
                                                                                                   val_loader,
                                                                                                   beta[epoch-1],
                                                                                                   sample_size,
                                                                                                   logger=logger)
        logger.log('eval/duration', time.time() - start_time, epoch)

      if epoch%checkpoint_freq==0:
        model_state = {'model': model.state_dict(), 'optimizer':optimizer, 'epoch':epoch}
        torch.save(model_state, checkpoint_path+f'checkpoint_{epoch}.pth')

      if logger:
        logger.log("train/loss", train_loss, epoch)
        logger.log("train/llh loss", train_llh_loss, epoch)
        logger.log("train/beta*KLD loss", train_KLD_loss, epoch)
        logger.log("train/beta*EKLD loss", train_EKLD_loss, epoch)
        logger.log("train/beta", beta[epoch-1], epoch)

        # NLL parts
        logger.log("train/grid llh loss", train_llh_parts_loss[0], epoch)
        logger.log("train/reward llh loss", train_llh_parts_loss[1], epoch)
        logger.log("train/term_state llh loss", train_llh_parts_loss[2], epoch)
        logger.log("train/action llh loss", train_llh_parts_loss[3], epoch)

        if beta[epoch-1]==0:
          logger.log("train/KLD loss", 0, epoch)
          logger.log("train/EKLD loss", 0, epoch)

        else:
          logger.log("train/KLD loss", train_KLD_loss/beta[epoch-1], epoch)
          logger.log("train/EKLD loss", train_EKLD_loss/beta[epoch-1], epoch)

        if val_loader:
          logger.log("eval/loss", val_loss, epoch)
          logger.log("eval/llh loss", val_llh_loss, epoch)
          logger.log("eval/beta*KLD loss", val_KLD_loss, epoch)
          logger.log("eval/beta*EKLD loss", val_EKLD_loss, epoch)
        
          # NLL Parts
          logger.log("eval/grid llh loss", val_llh_parts_loss[0], epoch)
          logger.log("eval/reward llh loss", val_llh_parts_loss[1], epoch)
          logger.log("eval/term_state llh loss", val_llh_parts_loss[2], epoch)
          logger.log("eval/action llh loss", val_llh_parts_loss[3], epoch)

          if beta[epoch-1]==0:
            logger.log("eval/KLD loss", 0, epoch)
            logger.log("eval/EKLD loss", 0, epoch)

          else:
            logger.log("eval/KLD loss", val_KLD_loss/beta[epoch-1], epoch)
            logger.log("eval/EKLD loss", val_EKLD_loss/beta[epoch-1], epoch)
        logger.dump(epoch)
      
    except KeyboardInterrupt:
      break

  torch.save(model.state_dict(), final_model_path+f'model.pth')

  return model