import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import argparse 

matplotlib.rcParams['mathtext.fontset'] = 'stix'
matplotlib.rcParams['font.family'] = 'STIXGeneral'

def main(args):
    df = pd.read_csv(args.data_path)
    step = df['step'][:-2]
    episode_reward_avg = df['episode_reward_avg'][:-2]
    episode_reward_std = df['episode_reward_std'][:-2]

    plt.fill_between(step/1e6, episode_reward_avg+episode_reward_std, episode_reward_avg-episode_reward_std, alpha=0.3)
    plt.plot(step/1e6, episode_reward_avg)
    
    plt.xlabel('Millions of Training Steps')
    plt.ylabel('Average Return')
    plt.ylim([(episode_reward_avg-episode_reward_std).min(), (episode_reward_avg+episode_reward_std).max()])
    plt.grid()
    plt.tight_layout()
    plt.savefig(f"out/{args.data_path.split('/')[-2]}_eval_reward.png", dpi=600, transparent=True)
    plt.savefig(f"out/{args.data_path.split('/')[-2]}_eval_reward.pdf", dpi=600)
    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", required=True)
    args = parser.parse_args()
    main(args)



