import imageio
import os
import numpy as np
import sys
import utils
import cv2 

class VideoRecorder(object):
    def __init__(self, save_dir, fps=5):
        self.save_dir = save_dir
        self.fps = fps
        self.frames = []

    def init(self, enabled=True):
        self.frames = []
        self.enabled = self.save_dir is not None and enabled

    def record(self, env, episode, returns, step, render_cfg=None):
        if self.enabled:
            frame = env.render() if render_cfg is None else env.render(**render_cfg)
            frame = cv2.putText(frame, 
                                text=f"E:{episode} S:{step} R:{returns:.3f}", 
                                org=(10, 30), 
                                fontFace=cv2.FONT_HERSHEY_SIMPLEX, 
                                fontScale=1,
                                color=(0,255,0),
                                thickness=2,
                                lineType=cv2.LINE_AA)
            self.frames.append(frame)

    def save(self, file_name):
        if self.enabled:
            path = os.path.join(self.save_dir, file_name)
            imageio.mimsave(path, self.frames, fps=self.fps)
