import torch
import torch.nn as nn
import torch.nn.functional as F

class Embedding(nn.Module):

    def __init__(self, num_categories, embedding_dim):
        super(Embedding, self).__init__()
        # i.e the dictionnary size
        self.num_categories = num_categories
        
        self.weight = nn.Parameter(torch.rand(num_categories, embedding_dim))

        self.device = torch.device('cuda:2')
        self.to(self.device)

        self.ones = torch.eye(num_categories, requires_grad=False).to(self.device)
      
    def forward(self, input):

        ohe = self.to_one_hot(input)

        result = torch.stack(
                [torch.mm(batch.float(), self.weight)
                 for batch in ohe], dim=0)
        return result

    def to_one_hot(self, input):
        # Returns a new tensor that doesn't share memory
        result = F.one_hot(input.long(), num_classes=self.num_categories)
        return result


class PartObsMiniGridEncoder(nn.Module):
    def __init__(self, cfg):
        super(PartObsMiniGridEncoder, self).__init__()
        image_shape = cfg['image_shape']
        image_channels = image_shape[0]  # 1 x 7 x 7
        self.device = cfg['device']
        self.action_dim = cfg['action_dim']
        self.term_state_dim = cfg['term_state_dim']
        self.scalar_emb_dim = cfg['scalar_emb_dim']

        self.device = torch.device(cfg['device'])
        
        self.obs_encoder = nn.Sequential(
            nn.Conv2d(image_channels, 8, kernel_size=3, padding=1), # B x 3 x 16 x 16 -> B x 8 x 16 x 16
            nn.Mish(),
            nn.Conv2d(8, 16, kernel_size=3, padding=1, stride=2), # B x 8 x 16 x 16 -> B x 16 x 8 x 8
            nn.Mish(),
            nn.Conv2d(16, 32, kernel_size=3, padding=1, stride=2), # B x 16 x 8 x 8 -> B x 32 x 4 x 4
            nn.Mish(),
            nn.Conv2d(32, 32, kernel_size=3, padding=1, stride=2), # B x 32 x 4 x 4 -> B x 16 x 2 x 2
            nn.Mish(),
            nn.Flatten() # B x 16 x 2 x 2  -> B x 64
        ) 

        self.reward_encoder = nn.Sequential(nn.Conv1d(1, self.scalar_emb_dim,1),
                                    nn.Mish(),
                                    nn.Conv1d(self.scalar_emb_dim, self.scalar_emb_dim,1),
                                    nn.Flatten()
                                    )

        self.action_embedding = Embedding(4, 10)

        self.action_encoder = nn.Sequential(nn.Conv1d(10, self.scalar_emb_dim,1),
                                    nn.Mish(),
                                    nn.Conv1d(self.scalar_emb_dim, self.scalar_emb_dim,1),
                                    nn.Flatten()
                                    )
        
        self.term_state_encoder = nn.Sequential(nn.Conv1d(1, self.scalar_emb_dim,1),
                                    nn.Mish(),
                                    nn.Conv1d(self.scalar_emb_dim, self.scalar_emb_dim,1),
                                    nn.Flatten()
                                    )
        self.regime_encoder = nn.Sequential(nn.Conv1d(1, self.scalar_emb_dim//2,1),
                                    nn.Mish(),
                                    nn.Conv1d(self.scalar_emb_dim//2, self.scalar_emb_dim//2,1),
                                    nn.Flatten()
                                    )

        self.to(self.device)

    def forward(self, x):
        obs = x['obs'].to(self.device)
        obs_shape = obs.shape
        obs = obs.reshape(-1, obs_shape[2],obs_shape[3],obs_shape[4])

        obs = self.obs_encoder(obs)
        
        # Un poco de reshaping
        rewards = x['rewards'].to(self.device)
        rewards_shape = rewards.shape
        rewards = rewards.reshape(-1, 1).unsqueeze(2)

        # Otro poco de reshaping
        actions = x['actions'].to(self.device)
        actions_shape = actions.shape
        actions = self.action_embedding(actions+1)
        actions = actions.reshape(-1, 10).unsqueeze(2)

        # Otro poco de reshaping
        term_states = x['term_states'].to(self.device)
        term_states_shape = term_states.shape
        term_states = term_states.reshape(-1, 1).unsqueeze(2) 

        # Otro poco de reshaping
        regimes = x['regimen'].to(self.device)
        regimes_shape = regimes.shape
        regimes = regimes.reshape(-1, 1).unsqueeze(2)


        # Codificacion
        rewards = self.reward_encoder(rewards)
        actions = self.action_encoder(actions)

        term_states = self.term_state_encoder(term_states)
        regimes = self.regime_encoder(regimes)

        # Reshape al shape original
        obs = obs.reshape(obs_shape[0], obs_shape[1],-1)
        rewards = rewards.reshape(rewards_shape[0], rewards_shape[1],-1)
        actions = actions.reshape(actions_shape[0], actions_shape[1],-1)
        term_states = term_states.reshape(term_states_shape[0], term_states_shape[1],-1)
        regimes = regimes.reshape(regimes_shape[0], regimes_shape[1],-1)
        

        z = torch.cat([obs, rewards, actions, term_states], dim=2)
        z = {'obs':obs, 'rewards':rewards, 'actions':actions, 'term_states':term_states, 'regimen': regimes}
        return z

    def log(self, logger, step):
        pass