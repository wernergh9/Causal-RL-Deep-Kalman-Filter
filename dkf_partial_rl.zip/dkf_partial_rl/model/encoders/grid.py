import torch
import torch.nn as nn


class MiniGridEncoder(nn.Module):
    def __init__(self, cfg):
        super(MiniGridEncoder, self).__init__()
        observation_space = cfg['obs_dim']
        image_shape = observation_space['image'].shape
        image_channels = image_shape[-1]  # 16 x 16 x 3
        self.device = cfg['device']
        self.scalar_dim = observation_space['direction'].n # 1
        self.scalar_emb_dim = cfg['scalar_emb_dim']
        self.map_encoder = nn.Sequential(
            nn.Conv2d(image_channels, 8, kernel_size=3, padding=1), # B x 3 x 16 x 16 -> B x 8 x 16 x 16
            nn.Mish(),
            nn.Conv2d(8, 16, kernel_size=3, padding=1, stride=2), # B x 8 x 16 x 16 -> B x 16 x 8 x 8
            nn.Mish(),
            nn.Conv2d(16, 32, kernel_size=3, padding=1, stride=2), # B x 16 x 8 x 8 -> B x 32 x 4 x 4
            nn.Mish(),
            nn.Conv2d(32, 16, kernel_size=3, padding=1, stride=2), # B x 32 x 4 x 4 -> B x 16 x 2 x 2
            nn.Mish(),
            nn.Flatten() # B x 16 x 2 x 2  -> B x 64
        ) 

        self.scalar_encoder = nn.Sequential(nn.Conv1d(1, self.scalar_emb_dim,1),
                                    nn.Mish(),
                                    nn.Conv1d(self.scalar_emb_dim, self.scalar_emb_dim,1),
                                    nn.Flatten()
                                    )
        
        self.state_encoding_dim = (image_shape[0]*image_shape[1])//4 + self.scalar_emb_dim

    def forward(self, x):
        map_obs = x['image']
        if not torch.is_tensor(map_obs):
            map_obs = torch.from_numpy(map_obs).float().to(self.device)
            map_obs = map_obs[None, :]
        else:
            map_obs = map_obs.squeeze()
        map_obs = map_obs.permute(0,3,1,2)
        
        m = self.map_encoder(map_obs)

        scalar_obs = x['direction']
        if not torch.is_tensor(scalar_obs):
            scalar_obs = torch.Tensor([scalar_obs]).unsqueeze(1).to(self.device)
            scalar_obs = self.scalar_encoder(scalar_obs).permute(1,0)
        else:
            scalar_obs = scalar_obs.unsqueeze(1).permute(1,0)
            scalar_obs = self.scalar_encoder(scalar_obs).permute(1,0)

        s = scalar_obs
        z = torch.cat([m, s], dim=1)
        return z

    def log(self, logger, step):
        pass


class ImaginaryEncoder(nn.Module):
    def __init__(self, cfg):
        super(ImaginaryEncoder, self).__init__()
        self.state_encoding_dim = cfg['obs_dim'].shape[0]
        self.device = cfg['device']

    def forward(self, x):
        if not torch.is_tensor(x):
            x = torch.tensor(x, device=self.device)
        return x

    def log(self, logger, step):
        pass