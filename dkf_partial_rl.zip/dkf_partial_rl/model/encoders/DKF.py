import torch
import torch.nn as nn
from torch.nn import functional as F
from itertools import chain
from model.encoders.grid_part_obs import PartObsMiniGridEncoder

class DeepKF(nn.Module):
    def __init__(self, cfg):
        super(DeepKF, self).__init__()
        
        self.input_dim =cfg['dkf']['settings']['input_dim']
        self.output_dim = cfg['dkf']['settings']['output_dim']
        self.dec_h_dims = cfg['dkf']['settings']['dec_h_dims']
        self.transition_h_dims = cfg['dkf']['settings']['transition_h_dims']
        self.l_d = cfg['dkf']['settings']['l_d']
        self.a_d = cfg['minigrid_encoder']['settings']['scalar_emb_dim']
        rnn = cfg['dkf']['settings']['rnn']
        self.rnn_layers = cfg['dkf']['settings']['rnn_layers']

        self.scalar_emb_dim = cfg['minigrid_encoder']['settings']['scalar_emb_dim']

        self.device = torch.device(cfg['dkf']['settings']['device'])

        #Encoder 

        self.rnn_hidden_state = None

        self.minigrid_encoder = PartObsMiniGridEncoder(cfg['minigrid_encoder']['settings'])
        if rnn == 'lstm':
          self.rnn = nn.LSTM(input_size=self.input_dim, hidden_size=self.l_d,num_layers=self.rnn_layers,batch_first=True)

          for name, param in self.rnn.named_parameters():
              if 'bias' in name:
                nn.init.constant_(param[self.l_d:2*self.l_d], 1.0)
        
        elif rnn == 'gru':
          self.rnn = nn.GRU(input_size=self.input_dim, hidden_size=self.l_d,num_layers=self.rnn_layers,batch_first=True)

        self.mu_z_encoder = nn.Linear(self.l_d, self.l_d)
        self.logvar_z_encoder = nn.Linear(self.l_d, self.l_d)

        # Decoder: should also be a probability distribution    
        hiddens_cat = [self.l_d,*self.dec_h_dims]

        self.pre_decoder = nn.Sequential(*list(chain.from_iterable(
                                     (nn.Linear(hiddens_cat[i],hiddens_cat[i+1]), nn.Tanh()) 
                                      for i in range(len(hiddens_cat)-1)))
                                    )

        hiddens_cat = [self.l_d+self.scalar_emb_dim//2,*self.dec_h_dims]

        self.action_pre_decoder = nn.Sequential(*list(chain.from_iterable(
                                     (nn.Linear(hiddens_cat[i],hiddens_cat[i+1]), nn.Tanh()) 
                                      for i in range(len(hiddens_cat)-1)))
                                    )

        self.num_fcs = len(cfg['obs_map'].keys())
        for i in range(self.num_fcs):
            setattr(self, "grid_decoder%d" % i, nn.Linear(self.dec_h_dims[-1], self.output_dim-2))

        self.reward_normal_weights_decoder = nn.Linear(self.dec_h_dims[-1],3)
        self.reward_mu_decoder = nn.Linear(self.dec_h_dims[-1],3)
        self.reward_logvar_decoder = nn.Linear(self.dec_h_dims[-1],3)
        self.term_state_params_decoder = nn.Linear(self.dec_h_dims[-1],1)
        self.action_params_decoder = nn.Linear(self.dec_h_dims[-1],4)
        
        #transition layer

        hidden_cat = [self.l_d+self.a_d,*self.transition_h_dims]

        self.z_transition = nn.Sequential(*list(chain.from_iterable(
                                     (nn.Linear(hidden_cat[i],hidden_cat[i+1]), nn.Mish()) 
                                      for i in range(len(hidden_cat)-1)))
                                    )
        
        self.mu_z_trans = nn.Linear(self.transition_h_dims[-1], self.l_d)
        self.logvar_z_trans = nn.Linear(self.transition_h_dims[-1], self.l_d) 

        self.to(self.device)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5*logvar)
        eps = torch.randn_like(std)
        return mu + eps*std      

    def reset_rnn_hidden_state(self):
        self.rnn_hidden_state = None 
        
    def encode(self, embedding, eval_mode=False):

        if eval_mode:
          h, self.rnn_hidden_state = self.rnn(embedding, self.rnn_hidden_state)
        else:
          h, _ = self.rnn(embedding)
        
        mu_z = self.mu_z_encoder(h)
        logvar_z = self.logvar_z_encoder(h)
        return mu_z, logvar_z

    def decode(self, z, regimes):
        z_regimes_cat = torch.cat((z,regimes), dim=2)
        h = self.pre_decoder(z)
        h_action = self.action_pre_decoder(z_regimes_cat)
        #mu_x = self.mu_x_decoder(h)
        #logvar_x = self.logvar_x_decoder(h)

        grid_params = []
        for i in range(self.num_fcs):
            grid_params.append(getattr(self, "grid_decoder%d" % i)(h))

        grid_params = torch.cat(grid_params, dim=2).reshape(z.shape[0], z.shape[1], self.output_dim-2, -1)

        reward_normal_weights = self.reward_normal_weights_decoder(h)
        reward_mus = self.reward_mu_decoder(h)
        reward_logvars = self.reward_logvar_decoder(h)
        term_state_params = self.term_state_params_decoder(h)
        action_params = self.action_params_decoder(h_action)

        return {'grid_params':grid_params,
                'reward_params': {'weights': reward_normal_weights, 'mus':reward_mus, 'logvars':reward_logvars},
                'term_state_params':term_state_params,
                'action_params': action_params}

    def transition(self, z, a):
        z_a = torch.cat((z,a),dim=2)

        h = self.z_transition(z_a)
        mu_z_next = self.mu_z_trans(h)
        logvar_z_next = self.logvar_z_trans(h)
        return mu_z_next, logvar_z_next

    def imagine_transition(self, z, action):
      # Create action embedding
      if not torch.is_tensor(action):
        action = torch.tensor([[action]], device=self.device, dtype=torch.float)

      action_shape = action.shape
      action_embedding = self.minigrid_encoder.action_embedding(action+1)
      action_embedding = action_embedding.reshape(-1, 10).unsqueeze(2)
      action_embedding = self.minigrid_encoder.action_encoder(action_embedding)

      # Create regime embedding
      regime = torch.ones_like(action)
      regime_shape = regime.shape
      regime = regime.reshape(-1, 1).unsqueeze(2)
      regime_embedding = self.minigrid_encoder.regime_encoder(regime)
      regime_embedding = regime_embedding.reshape(regime_shape[0], regime_shape[1],-1)
      
      # Transistion to next z dist parameters
      action_embedding = action_embedding.reshape(action_shape[0], action_shape[1],-1)
      mu_z_next, logvar_z_next = self.transition(z, action_embedding)
      # Sample a z
      z_next = self.reparameterize(mu_z_next, logvar_z_next)

      # Decode from z_next: q(o,r,d,a | z)
      decoder_params = self.decode(mu_z_next, regime_embedding)

      # Get reward and term stateparameters
      reward_normal_weights = decoder_params['reward_params']['weights']
      reward_mus = decoder_params['reward_params']['mus']
      reward_logvars = decoder_params['reward_params']['logvars']
      term_state_params = decoder_params['term_state_params']

      # Reward dist: q(r|z)
      mix = torch.distributions.Categorical(logits=reward_normal_weights)
      normal_comp = torch.distributions.Normal(reward_mus, torch.exp(0.5*reward_logvars))
      gaussian_mixture = torch.distributions.mixture_same_family.MixtureSameFamily(mix,normal_comp)

      # Term state dist: q(d|z)
      bernoulli = torch.distributions.bernoulli.Bernoulli(logits=torch.squeeze(term_state_params,dim=2))

      # Sample a reward:
      reward = gaussian_mixture.sample()

      # Sample term state:
      term_state = bernoulli.sample()

      return z_next, mu_z_next, logvar_z_next, reward, term_state

    def forward(self, data, sample_size=5):
        
        embedding = self.minigrid_encoder(data)

        obs_embedding = embedding['obs']
        rewards_embedding = embedding['rewards']
        actions_embedding = embedding['actions']
        term_states_embedding = embedding['term_states']
        regimes_embedding = embedding['regimen']

        cat_embedding = torch.cat((obs_embedding,
                                   rewards_embedding,
                                   actions_embedding,
                                   term_states_embedding),dim=2)

        # encoder
        mu_z, logvar_z = self.encode(cat_embedding) 

        # decoder
        z = self.reparameterize(mu_z, logvar_z)

        decoder_params = self.decode(z, regimes_embedding)
        #print("mu_x", mu_x.shape, "logvar_x", logvar_x.shape)

        # transition
        batches = data['obs'].shape[0]
        time_steps = data['obs'].shape[1]

        mu_z_nexts = torch.empty(sample_size, batches, time_steps-1, self.l_d, dtype=torch.float).to(self.device)
        logvar_z_nexts = torch.empty(sample_size, batches, time_steps-1, self.l_d, dtype=torch.float).to(self.device)
        
        for i in range(sample_size):

          z_tmp = self.reparameterize(mu_z, logvar_z)

          mu_z_next, logvar_z_next = self.transition(z_tmp[:,0:-1,:],embedding['actions'][:,1:,:])

          mu_z_nexts[i] = mu_z_next
          logvar_z_nexts[i] = logvar_z_next
        
        return decoder_params, mu_z, logvar_z, mu_z_nexts, logvar_z_nexts