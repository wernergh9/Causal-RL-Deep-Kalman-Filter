import gymnasium as gym
import minigrid
import PIL
import math
import torch
from model.encoders.DKF import DeepKF
from minigrid.wrappers import RGBImgPartialObsWrapper, ImgObsWrapper, RGBImgObsWrapper, ActionBonus, StateBonus, FullyObsWrapper
from minigrid.envs.crossing import CrossingEnv
from gymnasium import spaces
from gymnasium.envs.registration import register
from gymnasium.core import ObservationWrapper
import numpy as np
import yaml
from utils.train_dkf_utils import str_keys_to_float

env_names = {
    'lava crossing': 'MiniGrid-LavaCrossingS11N5-v0',
    'simple crossing': 'MiniGrid-SimpleCrossingS11N5-v0', 
    'mini dynamic obstacles': 'MiniGrid-Dynamic-Obstacles-8x8-v0',
    'random mini dynamic obstacles': 'MiniGrid-Dynamic-Obstacles-Random-8x8-v0',
    'random dynamic obstacles': 'MiniGrid-Dynamic-Obstacles-Random-16x16-v2',
    'dynamic obstacles': 'MiniGrid-Dynamic-Obstacles-16x16-v0',
    'door key': 'MiniGrid-DoorKey-5x5-v0',
    'empty': 'MiniGrid-Empty-16x16-v0'
}

register(
    id="MiniGrid-Dynamic-Obstacles-Random-8x8-v0",
    entry_point="minigrid.envs:DynamicObstaclesEnv",
    kwargs={"size": 8, "agent_start_pos": None, "n_obstacles": 3},
)


register(
    id="MiniGrid-Dynamic-Obstacles-Random-16x16-v2",
    entry_point="minigrid.envs:DynamicObstaclesEnv",
    kwargs={"size": 16, "agent_start_pos": None, "n_obstacles": 12},
)

class MiniGrid:
    def __init__(self, name, full_observability = False, state_bonus='none', only_movement=True, gamma=0.9, dense_reward=False, longest_distance=27):
        self.full_observability = full_observability
        self.env = gym.make(env_names[name])

        if full_observability:
            #self.env = FullyObsWrapper(self.env) # Get rid of the 'mission' field
            self.observation_space = FullyObsWrapper(self.env).observation_space
        else:
            self.observation_space = self.env.observation_space
        
        if state_bonus == 'action':
            self.env = ActionBonus(self.env)
        elif state_bonus == 'state':
            self.env = StateBonus(self.env)
        
        self.dense_reward = dense_reward
        self.gamma = gamma
        self.action_space = spaces.Discrete(3) if only_movement else self.env.action_space
        
        self.longest_distance = longest_distance
        self.steps = 0
        self.last_agent_pos = self.env.agent_pos

    def full_observation(self):
        env = self.env.env
        full_grid = env.grid.encode()
        full_grid[env.agent_pos[0]][env.agent_pos[1]] = np.array(
            [OBJECT_TO_IDX["agent"], COLOR_TO_IDX["red"], env.agent_dir]
        )
        return full_grid
    

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)

        partial_obs = obs['image']
        full_obs = self.full_observation()
        obs['image'] = full_obs
        obs['partial_image'] = partial_obs

        self.steps += 1
        info['optimal steps difference'] = 100
        info['success'] = False
        if terminated:
            info['success'] = reward > 0
            info['optimal steps difference'] = self.steps - self.optimal_steps if reward > 0 else 100
        if self.dense_reward:
            reward += self.gamma*self.position_potential(self.env.agent_pos) - self.position_potential(self.last_agent_pos)
            self.last_agent_pos = self.env.agent_pos
        return obs, reward, terminated, truncated, info
    
    def reset(self, seed=None):
        obs, _ = self.env.reset(seed=seed)

        partial_obs = obs['image']
        full_obs = self.full_observation()
        obs['image'] = full_obs
        obs['partial_image'] = partial_obs

        self.last_agent_pos = self.env.agent_pos
        self.starting_pos = self.env.agent_pos
        self.optimal_steps = self.longest_distance - (self.starting_pos[0] + self.starting_pos[1] + 1)  + (self.env.agent_dir > 1)
        self.steps = 0
        return obs
    
    def render(self):
        if self.full_observability:
            return self.env.get_full_render(False, 64)
        else:
            return self.env.get_frame(False, 64, True)

    def position_potential(self, position):
        return 0.01*(position[0] + position[1] - 2)


from minigrid.core.constants import (
    COLOR_TO_IDX,
    COLORS,
    IDX_TO_COLOR,
    IDX_TO_OBJECT,
    OBJECT_TO_IDX,
)

class FullPartialObsEnviroment(ObservationWrapper):    
    def __init__(self, enviroment):
        self.env = enviroment.env.env

    def full_observation(self):
        env = self.env
        full_grid = env.grid.encode()
        full_grid[env.agent_pos[0]][env.agent_pos[1]] = np.array(
            [OBJECT_TO_IDX["agent"], COLOR_TO_IDX["red"], env.agent_dir]
        )
        return full_grid
    
    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        obs["full_observation"] = self.full_observation()
        return obs, reward, terminated, truncated, info
    
    def reset(self, seed=None):
        obs, _ = self.env.reset(seed=seed)
        obs["full_observation"] = self.full_observation()
        return obs
    
    def render(self, full_observability=False):
        if full_observability:
            return self.env.get_full_render(False, 64)
        else:
            return self.env.get_frame(False, 64, True)

class ImaginaryMiniGrid:
    def __init__(self, dkf_cfg, dkf_path, real_env_cfg):

        with open("config/obs_map.yml", "r") as ymlfile:
            obs_map = str_keys_to_float(yaml.safe_load(ymlfile))

        #obs_map = {0.0:0, 1.0:1, 2.0:2, 6.0:3, 8.0:4}
        self.inv_obs_map = {v: k for k, v in obs_map.items()}
        self.colors = [
            None,
            np.array([0,0,0]),
            np.array([100,100,100]),
            None,
            None,
            None,
            np.array([255,0,0]),
            None,
            np.array([0,255,0]),
        ]
        self.dkf = DeepKF({'dkf': dkf_cfg, 'minigrid_encoder': dkf_cfg['minigrid_encoder'], 'obs_map':obs_map})
        self.dkf.load_state_dict(torch.load(dkf_path)['model'])

        self.real_env = MiniGrid(**real_env_cfg)
        self.observation_space = spaces.Box(
            low=-3,
            high=3,
            shape=(self.dkf.l_d, 1),
            dtype="float32"
        )
        self.action_space = self.real_env.action_space
        self.last_action = None

    def step(self, action, imaginary=True):
        if not imaginary:
            obs, reward, terminated, truncated, info = self.real_env.step(action)
            obs = torch.tensor(obs['partial_image'][:,:,0].reshape(1,1,1,7,7), dtype=torch.float)
            data = {'obs': obs,
                    'rewards': torch.tensor([[reward]], dtype=torch.float), 
                    'actions':  torch.tensor([[action]], dtype=torch.float),
                    'term_states': torch.tensor([[0]], dtype=torch.float), 
                    'regimen': torch.tensor([[1]], dtype=torch.float)
            }
            self.last_action = torch.tensor([[action]], dtype=torch.float)

            embedding = self.dkf.minigrid_encoder(data)
            obs_embedding = embedding['obs']
            rewards_embedding = embedding['rewards']
            actions_embedding = embedding['actions']
            term_states_embedding = embedding['term_states']
            cat_embedding = torch.cat((obs_embedding,
                                    rewards_embedding,
                                    actions_embedding,
                                    term_states_embedding), dim=2)
            mu_z, logvar_z = self.dkf.encode(cat_embedding, eval_mode=True) 

            #z = self.dkf.reparameterize(mu_z, logvar_z)

            obs = mu_z
            self.last_state = mu_z

            return obs, reward, terminated, truncated, info
        
        with torch.no_grad():
            sampled_z, mu_z_next, logvar_z_next, reward, terminated = self.dkf.imagine_transition(z=self.last_state, action=action)
        self.last_state = mu_z_next
        #self.last_state = sampled_z
        obs = mu_z_next
        #obs = sampled_z
        self.last_action = torch.tensor([[action]], dtype=torch.float)
        reward = reward.detach().cpu().numpy().squeeze()
        terminated = terminated.detach().cpu().squeeze()
        
        #return obs, torch.cat([mu_z_next, logvar_z_next]), reward, terminated, False, {}
        return obs.detach().cpu().numpy().reshape(1, -1), reward, terminated, False, {}

    def reset(self, seed=None, imaginary=True):
        with torch.no_grad():
            real_obs = self.real_env.reset(seed)
            data = {'obs': torch.tensor(real_obs['partial_image'][:,:,0].reshape(1,1,1,7,7), dtype=torch.float),
                    'rewards': torch.tensor([[0]], dtype=torch.float), 
                    'actions': torch.tensor([[-1]], dtype=torch.float), 
                    'term_states': torch.tensor([[0]], dtype=torch.float), 
                    'regimen': torch.tensor([[1]], dtype=torch.float)}

            self.last_action = torch.tensor([[-1]], dtype=torch.float)
        
            embedding = self.dkf.minigrid_encoder(data)

            obs_embedding = embedding['obs']
            rewards_embedding = embedding['rewards']
            actions_embedding = embedding['actions']
            term_states_embedding = embedding['term_states']
            regimes_embedding = embedding['regimen']

            cat_embedding = torch.cat((obs_embedding,
                                    rewards_embedding,
                                    actions_embedding,
                                    term_states_embedding),dim=2)

            # encoder
            self.dkf.reset_rnn_hidden_state()
            mu_z, logvar_z = self.dkf.encode(cat_embedding, eval_mode=True) 

            #z0 = self.dkf.reparameterize(mu_z, logvar_z)
            #self.last_state = z0
            self.last_state = mu_z

        #return z0.detach().cpu().numpy().squeeze().reshape(1, -1) #, mu_z, logvar_z
        return mu_z.detach().cpu().numpy().squeeze().reshape(1, -1)
    
    def render(self, imaginary=False):
        if imaginary:
            #Imaginary env
            regime = torch.ones_like(self.last_action).to(self.last_state.device)
            regime_shape = regime.shape
            regime = regime.reshape(-1, 1).unsqueeze(2)
            regime_embedding = self.dkf.minigrid_encoder.regime_encoder(regime)
            regime_embedding = regime_embedding.reshape(regime_shape[0], regime_shape[1],-1)

            decoder_params = self.dkf.decode(self.last_state, regime_embedding)

            # Grid reconstrucition
            grid_params = decoder_params['grid_params'].squeeze(0).squeeze(0)
            grid_argmax = torch.argmax(grid_params, 1, keepdim=True)
            recon_grid = grid_argmax.cpu().apply_(lambda val: self.inv_obs_map.get(val, -1)).numpy().reshape(7,7)
            image = np.zeros((512, 512, 3), dtype=np.uint8)
            x_step = 512 // 7
            y_step = 512 // 7
            for x in range(7):
                for y in range(7):
                    image[x_step*x:x_step*(x+1), y_step*y:y_step*(y+1), :] = self.colors[recon_grid[x,y]]
            return image
        # Real env
        image = self.real_env.render()        
        return image
