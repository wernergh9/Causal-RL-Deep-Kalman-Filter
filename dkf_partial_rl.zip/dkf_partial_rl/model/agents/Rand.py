from random import choices

class RandPolicy:
    def __init__(self):
        self.passed_action = None
        
    def act(self, *args):
        if self.passed_action == None or self.passed_action == 1:
            action = choices([0,1,2], weights = (0.2, 0.2, 0.6))[0]
        elif self.passed_action == 0:
            action = choices([0,1,2], weights = (0.3, 0.1, 0.6))[0]
        else:
            action = choices([0,1,2], weights = (0.1, 0.3, 0.6))[0]

        self.passed_action == action
        return action

    def reset(self):
        self.passed_action = None